export const setPrefCity = ({ city }) => ({
  type: 'change_city',
  payload: city,
});
