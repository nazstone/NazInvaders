const text = {
  fontSize: 24,
  fontWeight: '600',
};

const title = {
  fontSize: 34,
  fontWeight: '600',
};

export { text, title };
