const flex1 = {
  flex: 1,
};

export { flex1 };
