import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';

import List from './List';
import Detail from './Detail';
import { Image, Text } from 'react-native';
import { title } from '../utils/font';

const Stack = createStackNavigator();

const Home = () => {
  return (
    <Stack.Navigator initialRouteName="List">
      <Stack.Screen
        name="Invaders"
        component={List}
        options={({ navigation, route }) => ({
          headerTitle: (props) => {
            return <Text style={title}>{props.children}</Text>;
          },
          headerLeft: () => (
            <Image
              style={{
                height: 50,
                width: 50,
              }}
              resizeMode="center"
              onTouchEnd={() => {
                navigation.openDrawer();
              }}
              source={require('../../assets/img/menu.png')}
            />
          ),
        })}
      />
      <Stack.Screen name="Detail" component={Detail} />
    </Stack.Navigator>
  );
};

export default Home;
